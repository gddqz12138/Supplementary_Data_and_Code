# Energy-aware adaptive sensing with belief-state Q-learning

This package contains the complete, reproducible simulation study of reinforcement learning for balancing industrial sensing frequency against estimation accuracy, fault-detection performance, and per-acquisition energy cost.

**Disclaimer:** This package contains a synthetic-data simulation study provided for research and peer-review purposes only, without any claim of fitness for safety-critical or production deployment.

## Study at a glance

A scalar machine-health indicator evolves through normal, high-load, and fault regimes. Every minute, a controller either acquires a noisy measurement or skips it. A deliberately imperfect Kalman-style estimator maintains the estimated condition, uncertainty, and sample age. These three variables are discretized into 384 belief states. A two-action tabular Q-learning policy is trained offline to minimize a weighted sum of estimation error, acquisition cost, missed-fault cost, and false-alarm cost.

The main experiment uses ten training candidates, 100 validation shifts for model and baseline selection, and 300 untouched 12-hour test shifts. All nominal policies receive the same latent trajectories and measurement-noise streams. Episode-level additive outcomes are saved so that aggregate statistics, bootstrap intervals, and paired tests can be recomputed without rerunning training.

### Main frozen-test result

| Metric | Proposed RL | Tuned periodic | Tuned event trigger | Full-rate |
|---|---:|---:|---:|---:|
| Sensing rate | 0.3446 | 0.3333 | 0.4021 | 1.0000 |
| RMSE | 0.1514 | 0.1596 | 0.1500 | 0.1143 |
| Fault recall | 0.9529 | 0.9226 | 0.9287 | 0.9495 |
| F1 | 0.9384 | 0.9221 | 0.9262 | 0.9491 |
| Detection delay, min | 1.1787 | 2.0516 | 1.8679 | 1.1797 |
| Composite cost | 0.1947 | 0.2111 | 0.2088 | 0.2765 |

At the selected operating point, RL reduces acquisitions by 65.54% relative to full-rate sensing. Its composite cost is 7.76% below the tuned periodic policy and 6.75% below the tuned event trigger. These are simulation results under the explicitly defined normalized objective; they are not direct claims about battery life or a particular industrial asset.

## Reproducible contents

- `src/adaptive_sensing_rl.py`: simulator, estimator, Q-learning agent, baselines, and evaluators.
- `run_experiments.py`: complete train/validation/test, robustness, statistics, and figure pipeline.
- `verify_results.py`: independently recomputes key aggregates and replays the frozen Q-table.
- `results/`: episode-level data, summaries, selected parameters, training curves, metadata, and six trained Q-tables.
- `figures/`: PNG and vector-PDF versions of all seven figures.

**Note:** The released files have been verified using an automated check (`verify_results.py`) to ensure exact reproduction of all reported numerical results.

## Installation

The recorded run used Python 3.13.5. Create an isolated environment and install the pinned packages:

```bash
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements.txt