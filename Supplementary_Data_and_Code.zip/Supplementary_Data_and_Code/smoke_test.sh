#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"
rm -rf _quick_smoke
python run_experiments.py --quick --bootstrap 100 --root _quick_smoke

test -s _quick_smoke/results/main_results_summary.csv
test -s _quick_smoke/figures/figure_7_policy_behavior.png
echo "Smoke test passed. Outputs are in _quick_smoke/. Metrics are not publication results."
