#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"

echo "=================================================="
echo "Step 1: Running full experiments (this may take a while)..."
python run_experiments.py

echo ""
echo "=================================================="
echo "Step 2: Verifying results against the reported Q-tables..."
python verify_results.py

echo ""
echo "=================================================="
echo "Reproduction complete. Please check the 'results/' and 'figures/' directories."