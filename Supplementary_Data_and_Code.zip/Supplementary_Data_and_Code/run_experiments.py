#!/usr/bin/env python3
"""Run the complete reproducible adaptive-sensing simulation study.

Usage
-----
    python run_experiments.py

The default configuration reproduces all manuscript tables and figures.  A
smaller smoke test is available with ``--quick``.
"""
from __future__ import annotations

import argparse
import json
import math
import os
import platform
import sys
from pathlib import Path
from typing import Dict, Iterable, List, Mapping, Sequence, Tuple

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
import numba
import numpy as np
import pandas as pd
import scipy
from scipy.stats import wilcoxon

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "src"))

from adaptive_sensing_rl import (  # noqa: E402
    AGE_EDGES,
    FAULT_THRESHOLD,
    MU_EDGES,
    N_STATES,
    P_EDGES,
    POLICY_COVARIANCE,
    POLICY_EVENT,
    POLICY_PERIODIC,
    POLICY_Q,
    POLICY_RANDOM,
    RAW_COLUMNS,
    SCENARIO_NAMES,
    TrainingConfig,
    aggregate_metrics,
    evaluate_policy_raw,
    occupancy_statistics,
    q_policy_size_bytes,
    simulate_trace,
    train_q_learning,
)

MAIN_ENERGY_WEIGHT = 0.20
ENERGY_WEIGHTS = [0.02, 0.05, 0.10, 0.20, 0.40, 0.80]
POLICY_ORDER = [
    "Full-rate",
    "Periodic",
    "Covariance trigger",
    "Event trigger",
    "Random matched",
    "Proposed RL",
]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=ROOT, help="Project output root")
    parser.add_argument("--quick", action="store_true", help="Run a reduced smoke test")
    parser.add_argument("--bootstrap", type=int, default=4000, help="Bootstrap replications")
    return parser.parse_args()


def metrics_from_totals(totals: np.ndarray) -> Dict[str, np.ndarray]:
    """Vectorized aggregate metrics for one or many additive total rows."""
    arr = np.atleast_2d(np.asarray(totals, dtype=float))
    steps = arr[:, 0]
    samples = arr[:, 1]
    tp, fp, fn = arr[:, 4], arr[:, 5], arr[:, 6]
    recall = np.divide(tp, tp + fn, out=np.ones_like(tp), where=(tp + fn) > 0)
    precision = np.divide(tp, tp + fp, out=np.ones_like(tp), where=(tp + fp) > 0)
    f1 = np.divide(
        2.0 * recall * precision,
        recall + precision,
        out=np.zeros_like(recall),
        where=(recall + precision) > 0,
    )
    fault_events = arr[:, 10]
    return {
        "sensing_rate": samples / steps,
        "energy_saving_vs_full": 1.0 - samples / steps,
        "rmse": np.sqrt(arr[:, 2] / steps),
        "mae": arr[:, 3] / steps,
        "recall": recall,
        "precision": precision,
        "f1": f1,
        "composite_cost": arr[:, 7] / steps,
        "fault_prevalence": arr[:, 8] / steps,
        "detection_delay": np.divide(
            arr[:, 9], fault_events, out=np.zeros_like(fault_events), where=fault_events > 0
        ),
        "fault_events": fault_events,
    }


def bootstrap_summary(
    raw: np.ndarray,
    replications: int,
    seed: int,
    confidence: float = 0.95,
) -> Dict[str, float]:
    """Micro-aggregate point estimates and episode-cluster bootstrap intervals."""
    point = aggregate_metrics(raw)
    rng = np.random.default_rng(seed)
    metric_names = list(point.keys())
    draws: Dict[str, List[np.ndarray]] = {name: [] for name in metric_names}
    n = raw.shape[0]
    chunk_size = min(500, replications)
    completed = 0
    while completed < replications:
        chunk = min(chunk_size, replications - completed)
        indices = rng.integers(0, n, size=(chunk, n))
        totals = raw[indices].sum(axis=1)
        metrics = metrics_from_totals(totals)
        for name in metric_names:
            draws[name].append(metrics[name])
        completed += chunk

    alpha = 1.0 - confidence
    result: Dict[str, float] = {}
    for name in metric_names:
        samples = np.concatenate(draws[name])
        result[name] = float(point[name])
        result[f"{name}_ci_low"] = float(np.quantile(samples, alpha / 2.0))
        result[f"{name}_ci_high"] = float(np.quantile(samples, 1.0 - alpha / 2.0))
    return result


def raw_to_frame(raw: np.ndarray, seeds: np.ndarray, **metadata: object) -> pd.DataFrame:
    frame = pd.DataFrame(raw, columns=RAW_COLUMNS)
    frame.insert(0, "seed", seeds.astype(int))
    for key, value in reversed(list(metadata.items())):
        frame.insert(0, key, value)
    episode_metrics = metrics_from_totals(raw)
    for name, values in episode_metrics.items():
        frame[name] = values
    return frame


def evaluate_and_summarize(
    q_table: np.ndarray,
    energy_weight: float,
    seeds: np.ndarray,
    horizon: int,
    scenario: int,
    policy: int,
    parameter_1: float,
    parameter_2: float,
    bootstrap_replications: int,
    bootstrap_seed: int,
) -> Tuple[np.ndarray, Dict[str, float]]:
    raw = evaluate_policy_raw(
        q_table,
        energy_weight,
        seeds,
        horizon,
        scenario,
        policy,
        parameter_1,
        parameter_2,
    )
    return raw, bootstrap_summary(raw, bootstrap_replications, bootstrap_seed)


def tune_baselines(
    q_table: np.ndarray,
    validation_seeds: np.ndarray,
    horizon: int,
    energy_weight: float,
) -> Tuple[Dict[str, Dict[str, float]], pd.DataFrame]:
    rows: List[Dict[str, float | str]] = []

    periodic_grid = [1, 2, 3, 4, 5, 6, 8, 12, 16, 24]
    for interval in periodic_grid:
        raw = evaluate_policy_raw(
            q_table, energy_weight, validation_seeds, horizon, 0,
            POLICY_PERIODIC, float(interval), 0.0,
        )
        metrics = aggregate_metrics(raw)
        rows.append({"baseline": "Periodic", "parameter_1": interval, "parameter_2": np.nan, **metrics})

    covariance_grid = [0.025, 0.030, 0.040, 0.045, 0.050, 0.060, 0.070, 0.080, 0.100, 0.120, 0.140, 0.180, 0.200, 0.250, 0.300]
    for threshold in covariance_grid:
        raw = evaluate_policy_raw(
            q_table, energy_weight, validation_seeds, horizon, 0,
            POLICY_COVARIANCE, float(threshold), 0.0,
        )
        metrics = aggregate_metrics(raw)
        rows.append({"baseline": "Covariance trigger", "parameter_1": threshold, "parameter_2": np.nan, **metrics})

    event_p_grid = [0.030, 0.040, 0.050, 0.060, 0.070, 0.080, 0.100, 0.120, 0.140, 0.180, 0.200]
    event_z_grid = [1.0, 1.5, 2.0]
    for p_threshold in event_p_grid:
        for z_threshold in event_z_grid:
            raw = evaluate_policy_raw(
                q_table, energy_weight, validation_seeds, horizon, 0,
                POLICY_EVENT, float(p_threshold), float(z_threshold),
            )
            metrics = aggregate_metrics(raw)
            rows.append({
                "baseline": "Event trigger",
                "parameter_1": p_threshold,
                "parameter_2": z_threshold,
                **metrics,
            })

    tuning = pd.DataFrame(rows)
    selected: Dict[str, Dict[str, float]] = {}
    for name in ["Periodic", "Covariance trigger", "Event trigger"]:
        subset = tuning[tuning["baseline"] == name]
        row = subset.loc[subset["composite_cost"].idxmin()]
        selected[name] = {
            "parameter_1": float(row["parameter_1"]),
            "parameter_2": 0.0 if pd.isna(row["parameter_2"]) else float(row["parameter_2"]),
            "validation_cost": float(row["composite_cost"]),
            "validation_sensing_rate": float(row["sensing_rate"]),
        }
    return selected, tuning


def holm_adjust(p_values: Sequence[float]) -> np.ndarray:
    p = np.asarray(p_values, dtype=float)
    order = np.argsort(p)
    adjusted = np.empty_like(p)
    running = 0.0
    m = len(p)
    for rank, index in enumerate(order):
        candidate = min(1.0, (m - rank) * p[index])
        running = max(running, candidate)
        adjusted[index] = running
    return adjusted


def paired_cost_tests(
    episode_frames: Mapping[str, pd.DataFrame],
    reference: str = "Proposed RL",
    bootstrap_replications: int = 10000,
    seed: int = 20260721,
) -> pd.DataFrame:
    rows: List[Dict[str, float | str]] = []
    rng = np.random.default_rng(seed)
    reference_cost = episode_frames[reference]["composite_cost"].to_numpy()
    for comparator, frame in episode_frames.items():
        if comparator == reference:
            continue
        comparator_cost = frame["composite_cost"].to_numpy()
        # Positive difference means the comparator is more costly than RL.
        difference = comparator_cost - reference_cost
        statistic, p_value = wilcoxon(difference, alternative="two-sided", zero_method="wilcox")
        indices = rng.integers(0, difference.size, size=(bootstrap_replications, difference.size))
        draws = difference[indices].mean(axis=1)
        rows.append({
            "comparison": f"{reference} vs {comparator}",
            "comparator": comparator,
            "mean_cost_advantage": float(difference.mean()),
            "ci_low": float(np.quantile(draws, 0.025)),
            "ci_high": float(np.quantile(draws, 0.975)),
            "wilcoxon_statistic": float(statistic),
            "p_value": float(p_value),
        })
    result = pd.DataFrame(rows)
    result["p_holm"] = holm_adjust(result["p_value"].to_numpy())
    return result


def save_q_policy(path: Path, q_table: np.ndarray, energy_weight: float, selected_seed: int) -> None:
    np.savez_compressed(
        path,
        q_table=q_table,
        energy_weight=float(energy_weight),
        selected_training_seed=int(selected_seed),
        mu_edges=MU_EDGES,
        variance_edges=P_EDGES,
        age_edges=AGE_EDGES,
        fault_threshold=FAULT_THRESHOLD,
    )


def configure_plotting() -> None:
    plt.rcParams.update({
        "font.family": "DejaVu Serif",
        "font.size": 9.5,
        "axes.titlesize": 10.5,
        "axes.labelsize": 9.5,
        "legend.fontsize": 8.5,
        "xtick.labelsize": 8.5,
        "ytick.labelsize": 8.5,
        "figure.dpi": 150,
        "savefig.dpi": 300,
        "savefig.bbox": "tight",
        "axes.grid": True,
        "grid.alpha": 0.25,
    })


def save_figure(fig: plt.Figure, figures_dir: Path, stem: str) -> None:
    fig.savefig(figures_dir / f"{stem}.png")
    fig.savefig(figures_dir / f"{stem}.pdf")
    plt.close(fig)


def plot_framework(figures_dir: Path) -> None:
    """Draw a compact, publication-safe overview without overlapping labels."""
    fig, ax = plt.subplots(figsize=(8.0, 3.35))
    ax.set_xlim(0, 12)
    ax.set_ylim(0, 5.3)
    ax.axis("off")

    # Offline-training objective banner.
    banner = FancyBboxPatch(
        (1.0, 4.25), 10.0, 0.65,
        boxstyle="round,pad=0.05,rounding_size=0.08",
        linewidth=0.9, edgecolor="black", facecolor="white",
    )
    ax.add_patch(banner)
    ax.text(
        6.0, 4.575,
        "Offline objective (simulator/digital twin only): estimation error + sensing energy + alarm penalties",
        ha="center", va="center", fontsize=9.2, fontweight="bold",
    )

    boxes = [
        (0.25, 2.25, 2.0, 1.2, "Industrial asset\nlatent condition $x_t$"),
        (3.0, 2.25, 2.0, 1.2, "Physical sensor\nsample / skip"),
        (5.75, 2.25, 2.0, 1.2, "Belief estimator\n$\\hat{x}_t, P_t, \\tau_t$"),
        (8.50, 2.25, 2.0, 1.2, "Discretized state\n$s_t=b(\\hat{x}_t,P_t,\\tau_t)$"),
        (8.50, 0.35, 2.0, 1.15, "Q-learning policy\n$\\arg\\max_a Q(s_t,a)$"),
    ]
    for x, y, w, h, text in boxes:
        patch = FancyBboxPatch(
            (x, y), w, h,
            boxstyle="round,pad=0.04,rounding_size=0.08",
            linewidth=1.0, edgecolor="black", facecolor="white",
        )
        ax.add_patch(patch)
        ax.text(x + w / 2, y + h / 2, text, ha="center", va="center", fontsize=9.2)

    arrow = dict(arrowstyle="->", linewidth=1.15, color="black", shrinkA=5, shrinkB=5)
    ax.annotate("", xy=(3.0, 2.85), xytext=(2.25, 2.85), arrowprops=arrow)
    ax.text(2.62, 3.04, "$x_t$", ha="center", va="bottom", fontsize=8.6)

    ax.annotate("", xy=(5.75, 2.85), xytext=(5.0, 2.85), arrowprops=arrow)
    ax.text(5.38, 3.04, "$y_t$ when sampled", ha="center", va="bottom", fontsize=8.2)

    ax.annotate("", xy=(8.50, 2.85), xytext=(7.75, 2.85), arrowprops=arrow)
    ax.text(8.12, 3.04, "belief", ha="center", va="bottom", fontsize=8.2)

    ax.annotate("", xy=(9.50, 1.50), xytext=(9.50, 2.25), arrowprops=arrow)

    # Curved feedback arrow keeps the action label clear of all boxes.
    ax.annotate(
        "", xy=(4.0, 2.25), xytext=(8.50, 0.92),
        arrowprops={**arrow, "connectionstyle": "arc3,rad=-0.18"},
    )
    ax.text(6.15, 0.48, "next sensing action $a_t$", ha="center", va="center", fontsize=8.4)

    # The reward is only required while training; the deployed policy uses the state alone.
    ax.annotate(
        "training reward", xy=(10.05, 1.50), xytext=(10.05, 4.25),
        arrowprops={**arrow, "linestyle": "--"},
        ha="left", va="center", fontsize=8.1,
    )
    save_figure(fig, figures_dir, "figure_1_framework")


def rolling_mean(values: np.ndarray, window: int) -> np.ndarray:
    values = np.asarray(values, dtype=float)
    if values.size < window:
        return values
    kernel = np.ones(window) / window
    return np.convolve(values, kernel, mode="valid")


def plot_training_curve(curves: pd.DataFrame, selected_seed: int, figures_dir: Path) -> None:
    subset = curves[curves["training_seed"] == selected_seed].sort_values("episode")
    window = 100
    cost = rolling_mean(subset["exploratory_cost"].to_numpy(), window)
    rate = rolling_mean(subset["exploratory_sensing_rate"].to_numpy(), window)
    episodes = subset["episode"].to_numpy()[window - 1:]

    fig, ax1 = plt.subplots(figsize=(7.2, 3.4))
    line1, = ax1.plot(episodes, cost, linewidth=1.5, label="Composite cost")
    ax1.set_xlabel("Training episode")
    ax1.set_ylabel("100-episode moving-average cost")
    ax1.set_title(f"Q-learning convergence diagnostic (selected seed {selected_seed})")
    ax2 = ax1.twinx()
    line2, = ax2.plot(episodes, rate, linestyle="--", linewidth=1.3, label="Sensing rate")
    ax2.set_ylabel("100-episode moving-average sensing rate")
    ax1.legend([line1, line2], [line1.get_label(), line2.get_label()], loc="upper right")
    save_figure(fig, figures_dir, "figure_2_training_curve")


def plot_trace(trace: pd.DataFrame, figures_dir: Path, seed: int) -> None:
    time_hours = trace["time_min"].to_numpy() / 60.0
    condition = trace["condition"].to_numpy()
    estimate = trace["estimate"].to_numpy()
    observations = trace["observation"].to_numpy()
    actions = trace["action"].to_numpy()
    variance = trace["variance"].to_numpy()

    fig, axes = plt.subplots(2, 1, figsize=(7.2, 5.0), sharex=True, gridspec_kw={"height_ratios": [2.2, 1.0]})
    ax = axes[0]
    ax.plot(time_hours, condition, linewidth=1.4, label="Latent condition")
    ax.plot(time_hours, estimate, linewidth=1.25, label="Belief mean")
    mask = np.isfinite(observations)
    ax.scatter(time_hours[mask], observations[mask], s=7, alpha=0.55, label="Acquired sample")
    ax.axhline(FAULT_THRESHOLD, linestyle="--", linewidth=1.0, label="Fault threshold")
    ax.fill_between(time_hours, 0, 1, where=condition >= FAULT_THRESHOLD,
                    transform=ax.get_xaxis_transform(), alpha=0.10, label="True fault interval")
    ax.set_ylabel("Normalized condition")
    ax.set_title(f"Representative 12-hour adaptive-sensing trajectory (test seed {seed})")
    ax.legend(loc="upper left", ncol=2)

    ax2 = axes[1]
    ax2.plot(time_hours, variance, linewidth=1.2, label="Belief variance $P_t$")
    sample_times = time_hours[actions > 0]
    ax2.vlines(sample_times, 0, np.nanmax(variance) * 0.22, linewidth=0.55, alpha=0.7, label="Sense action")
    ax2.set_xlabel("Shift time (hours)")
    ax2.set_ylabel("Variance")
    ax2.legend(loc="upper left", ncol=2)
    save_figure(fig, figures_dir, "figure_3_representative_trace")


def _ci_error(summary: pd.DataFrame, metric: str) -> np.ndarray:
    point = summary[metric].to_numpy()
    lower = point - summary[f"{metric}_ci_low"].to_numpy()
    upper = summary[f"{metric}_ci_high"].to_numpy() - point
    return np.vstack([lower, upper])


def plot_main_comparison(summary: pd.DataFrame, figures_dir: Path) -> None:
    ordered = summary.set_index("policy").loc[POLICY_ORDER].reset_index()
    metrics = [
        ("sensing_rate", "Sensing rate", (0, 1.05)),
        ("rmse", "RMSE", None),
        ("recall", "Fault recall", (0.75, 1.01)),
        ("composite_cost", "Composite cost", None),
    ]
    fig, axes = plt.subplots(2, 2, figsize=(7.2, 6.0))
    labels = ["Full", "Periodic", "Covariance", "Event", "Random", "RL"]
    x = np.arange(len(labels))
    for ax, (metric, title, ylim) in zip(axes.ravel(), metrics):
        ax.bar(x, ordered[metric].to_numpy(), yerr=_ci_error(ordered, metric), capsize=2.5, linewidth=0.6, edgecolor="black")
        ax.set_title(title)
        ax.set_xticks(x)
        ax.set_xticklabels(labels, rotation=25, ha="right")
        if ylim is not None:
            ax.set_ylim(*ylim)
    fig.suptitle("Nominal test-set comparison (95% episode-bootstrap intervals)", y=1.01, fontweight="bold")
    fig.tight_layout()
    save_figure(fig, figures_dir, "figure_4_main_comparison")


def plot_pareto(pareto: pd.DataFrame, figures_dir: Path) -> None:
    fig, axes = plt.subplots(1, 2, figsize=(7.2, 3.4))
    ax = axes[0]
    for method, marker, linestyle in [
        ("RL energy sweep", "o", "-"),
        ("Periodic grid", "s", "--"),
        ("Covariance grid", "^", ":"),
    ]:
        subset = pareto[pareto["method"] == method].sort_values("sensing_rate")
        ax.plot(subset["sensing_rate"], subset["rmse"], marker=marker, linestyle=linestyle, linewidth=1.1, markersize=4, label=method)
    rl = pareto[pareto["method"] == "RL energy sweep"]
    for _, row in rl.iterrows():
        ax.annotate(row["label"], (row["sensing_rate"], row["rmse"]), xytext=(3, 3), textcoords="offset points", fontsize=7.5)
    ax.set_xlabel("Sensing rate")
    ax.set_ylabel("RMSE")
    ax.set_title("Accuracy–frequency frontier")
    ax.legend()

    ax = axes[1]
    for method, marker, linestyle in [
        ("RL energy sweep", "o", "-"),
        ("Periodic grid", "s", "--"),
        ("Covariance grid", "^", ":"),
    ]:
        subset = pareto[pareto["method"] == method].sort_values("sensing_rate")
        ax.plot(subset["sensing_rate"], subset["f1"], marker=marker, linestyle=linestyle, linewidth=1.1, markersize=4, label=method)
    ax.set_xlabel("Sensing rate")
    ax.set_ylabel("Fault F1 score")
    ax.set_title("Detection–frequency frontier")
    ax.set_ylim(0.70, 0.96)
    fig.tight_layout()
    save_figure(fig, figures_dir, "figure_5_pareto_frontier")


def plot_robustness(summary: pd.DataFrame, figures_dir: Path) -> None:
    policies = ["Full-rate", "Periodic", "Event trigger", "Proposed RL"]
    scenarios = [SCENARIO_NAMES[i] for i in range(4)]
    x = np.arange(len(scenarios))
    width = 0.19
    fig, axes = plt.subplots(1, 2, figsize=(7.2, 3.7))
    for p_index, policy in enumerate(policies):
        subset = summary[summary["policy"] == policy].set_index("scenario").loc[scenarios]
        offset = (p_index - (len(policies) - 1) / 2) * width
        axes[0].bar(x + offset, subset["composite_cost"], width, label=policy)
        axes[1].bar(x + offset, subset["recall"], width, label=policy)
    for ax, title, ylabel in [
        (axes[0], "Composite cost under model mismatch", "Composite cost"),
        (axes[1], "Fault recall under model mismatch", "Recall"),
    ]:
        ax.set_title(title)
        ax.set_xticks(x)
        ax.set_xticklabels(["Nominal", "More meas.\nnoise", "More fault\nentries", "Faster\ndynamics"], rotation=0)
        ax.set_ylabel(ylabel)
    axes[1].set_ylim(0.72, 1.0)
    axes[0].legend(loc="upper left", fontsize=7.4)
    fig.tight_layout()
    save_figure(fig, figures_dir, "figure_6_robustness")


def plot_policy_behavior(behavior: pd.DataFrame, figures_dir: Path) -> None:
    fig, axes = plt.subplots(1, 2, figsize=(7.2, 3.3))
    x = np.arange(len(behavior))
    labels = behavior["condition_region"].tolist()
    axes[0].bar(x, behavior["sensing_probability"], edgecolor="black", linewidth=0.6)
    axes[0].set_xticks(x)
    axes[0].set_xticklabels(labels, rotation=20, ha="right")
    axes[0].set_ylim(0, 1.05)
    axes[0].set_ylabel("Empirical sensing probability")
    axes[0].set_title("Action allocation by belief region")

    axes[1].bar(x, behavior["decision_share"], edgecolor="black", linewidth=0.6)
    axes[1].set_xticks(x)
    axes[1].set_xticklabels(labels, rotation=20, ha="right")
    axes[1].set_ylabel("Share of all decisions")
    axes[1].set_title("State-region occupancy")
    fig.tight_layout()
    save_figure(fig, figures_dir, "figure_7_policy_behavior")


def find_representative_seed(q_table: np.ndarray, test_seeds: np.ndarray, horizon: int) -> Tuple[int, Dict[str, np.ndarray]]:
    candidates: List[Tuple[float, int, Dict[str, np.ndarray]]] = []
    for seed in test_seeds:
        trace = simulate_trace(q_table, int(seed), horizon, 0)
        condition = trace["condition"]
        action = trace["action"]
        fault = condition >= FAULT_THRESHOLD
        entries = int(np.sum((fault.astype(int) - np.r_[0, fault[:-1].astype(int)]) == 1))
        fault_steps = int(fault.sum())
        rate = float(action.mean())
        if entries >= 1 and 25 <= fault_steps <= 250:
            score = abs(rate - 0.35) + abs(fault_steps - 90) / 720.0 - min(entries, 3) * 0.03
            candidates.append((score, int(seed), trace))
    if not candidates:
        seed = int(test_seeds[0])
        return seed, simulate_trace(q_table, seed, horizon, 0)
    candidates.sort(key=lambda item: item[0])
    _, seed, trace = candidates[0]
    return seed, trace


def main() -> None:
    args = parse_args()
    project_root = args.root.resolve()
    src_dir = project_root / "src"
    results_dir = project_root / "results"
    figures_dir = project_root / "figures"
    model_dir = results_dir / "models"
    for directory in [src_dir, results_dir, figures_dir, model_dir]:
        directory.mkdir(parents=True, exist_ok=True)

    if args.quick:
        config = TrainingConfig(episodes=120, horizon=180)
        main_training_seeds = np.arange(1, 4)
        sweep_training_seeds = np.arange(1, 3)
        validation_seeds = np.arange(12_000, 12_020)
        test_seeds = np.arange(20_000, 20_040)
        bootstrap_replications = min(args.bootstrap, 300)
    else:
        config = TrainingConfig(episodes=1800, horizon=720)
        main_training_seeds = np.arange(1, 11)
        sweep_training_seeds = np.arange(1, 7)
        validation_seeds = np.arange(12_000, 12_100)
        test_seeds = np.arange(20_000, 20_300)
        bootstrap_replications = args.bootstrap

    print(f"Training {len(main_training_seeds)} main Q-learning candidates...")
    candidate_rows: List[Dict[str, float | int]] = []
    training_curve_frames: List[pd.DataFrame] = []
    q_candidates: Dict[int, np.ndarray] = {}
    for training_seed in main_training_seeds:
        q_table, train_cost, train_rate = train_q_learning(MAIN_ENERGY_WEIGHT, int(training_seed), config)
        q_candidates[int(training_seed)] = q_table
        validation_raw = evaluate_policy_raw(
            q_table, MAIN_ENERGY_WEIGHT, validation_seeds, config.horizon, 0, POLICY_Q, 0.0, 0.0
        )
        validation_metrics = aggregate_metrics(validation_raw)
        candidate_rows.append({"training_seed": int(training_seed), **validation_metrics})
        training_curve_frames.append(pd.DataFrame({
            "energy_weight": MAIN_ENERGY_WEIGHT,
            "training_seed": int(training_seed),
            "episode": np.arange(1, config.episodes + 1),
            "exploratory_cost": train_cost,
            "exploratory_sensing_rate": train_rate,
        }))
        print(f"  seed {training_seed}: validation cost={validation_metrics['composite_cost']:.5f}, rate={validation_metrics['sensing_rate']:.3f}")

    candidate_table = pd.DataFrame(candidate_rows).sort_values("composite_cost")
    selected_seed = int(candidate_table.iloc[0]["training_seed"])
    selected_q = q_candidates[selected_seed]
    candidate_table.to_csv(results_dir / "rl_seed_selection.csv", index=False)
    training_curves = pd.concat(training_curve_frames, ignore_index=True)
    training_curves.to_csv(results_dir / "training_curves_main.csv", index=False)
    save_q_policy(model_dir / "selected_policy_lambda_0p20.npz", selected_q, MAIN_ENERGY_WEIGHT, selected_seed)
    print(f"Selected main training seed: {selected_seed}")

    print("Tuning non-learning baselines on the validation set...")
    selected_baselines, tuning_table = tune_baselines(
        selected_q, validation_seeds, config.horizon, MAIN_ENERGY_WEIGHT
    )
    tuning_table.to_csv(results_dir / "baseline_tuning.csv", index=False)
    validation_rl = evaluate_policy_raw(
        selected_q, MAIN_ENERGY_WEIGHT, validation_seeds, config.horizon, 0, POLICY_Q, 0.0, 0.0
    )
    validation_rl_rate = aggregate_metrics(validation_rl)["sensing_rate"]
    selected_baselines["Random matched"] = {
        "parameter_1": float(validation_rl_rate),
        "parameter_2": 0.0,
        "validation_cost": math.nan,
        "validation_sensing_rate": float(validation_rl_rate),
    }
    with (results_dir / "selected_hyperparameters.json").open("w", encoding="utf-8") as handle:
        json.dump({
            "rl": {"energy_weight": MAIN_ENERGY_WEIGHT, "training_seed": selected_seed},
            "baselines": selected_baselines,
        }, handle, indent=2)

    print("Evaluating the frozen policies on the independent nominal test set...")
    policies: Dict[str, Tuple[int, float, float]] = {
        "Full-rate": (POLICY_PERIODIC, 1.0, 0.0),
        "Periodic": (POLICY_PERIODIC, selected_baselines["Periodic"]["parameter_1"], 0.0),
        "Covariance trigger": (POLICY_COVARIANCE, selected_baselines["Covariance trigger"]["parameter_1"], 0.0),
        "Event trigger": (POLICY_EVENT, selected_baselines["Event trigger"]["parameter_1"], selected_baselines["Event trigger"]["parameter_2"]),
        "Random matched": (POLICY_RANDOM, validation_rl_rate, 0.0),
        "Proposed RL": (POLICY_Q, 0.0, 0.0),
    }

    main_episode_frames: Dict[str, pd.DataFrame] = {}
    summary_rows: List[Dict[str, float | str]] = []
    for index, policy_name in enumerate(POLICY_ORDER):
        policy_id, p1, p2 = policies[policy_name]
        raw, summary = evaluate_and_summarize(
            selected_q, MAIN_ENERGY_WEIGHT, test_seeds, config.horizon, 0,
            policy_id, p1, p2, bootstrap_replications, 1000 + index,
        )
        frame = raw_to_frame(
            raw, test_seeds, policy=policy_name, scenario=SCENARIO_NAMES[0],
            parameter_1=p1, parameter_2=p2,
        )
        main_episode_frames[policy_name] = frame
        summary_rows.append({"policy": policy_name, "parameter_1": p1, "parameter_2": p2, **summary})
        print(f"  {policy_name:20s}: rate={summary['sensing_rate']:.3f}, RMSE={summary['rmse']:.4f}, recall={summary['recall']:.3f}, cost={summary['composite_cost']:.4f}")

    main_episode_results = pd.concat(main_episode_frames.values(), ignore_index=True)
    main_episode_results.to_csv(results_dir / "main_episode_results.csv", index=False)
    main_summary = pd.DataFrame(summary_rows)
    main_summary.to_csv(results_dir / "main_results_summary.csv", index=False)

    tests = paired_cost_tests(main_episode_frames, bootstrap_replications=10_000 if not args.quick else 500)
    tests.to_csv(results_dir / "paired_statistical_tests.csv", index=False)

    print("Training the energy-weight sweep for the Pareto study...")
    sweep_rows: List[Dict[str, float | int]] = []
    sweep_selection_rows: List[Dict[str, float | int]] = []
    selected_sweep_q: Dict[float, np.ndarray] = {}
    for weight in ENERGY_WEIGHTS:
        if math.isclose(weight, MAIN_ENERGY_WEIGHT):
            best_q = selected_q
            best_seed = selected_seed
            best_val = aggregate_metrics(validation_rl)
        else:
            candidates: List[Tuple[float, int, np.ndarray, Dict[str, float]]] = []
            for training_seed in sweep_training_seeds:
                q_table, _, _ = train_q_learning(weight, int(training_seed), config)
                val_raw = evaluate_policy_raw(q_table, weight, validation_seeds, config.horizon, 0, POLICY_Q, 0.0, 0.0)
                val_metrics = aggregate_metrics(val_raw)
                candidates.append((val_metrics["composite_cost"], int(training_seed), q_table, val_metrics))
                sweep_selection_rows.append({
                    "energy_weight": weight,
                    "training_seed": int(training_seed),
                    **val_metrics,
                })
            candidates.sort(key=lambda item: item[0])
            _, best_seed, best_q, best_val = candidates[0]
        selected_sweep_q[weight] = best_q
        safe_weight = f"{weight:.2f}".replace(".", "p")
        save_q_policy(model_dir / f"selected_policy_lambda_{safe_weight}.npz", best_q, weight, best_seed)
        test_raw = evaluate_policy_raw(best_q, weight, test_seeds, config.horizon, 0, POLICY_Q, 0.0, 0.0)
        metrics = aggregate_metrics(test_raw)
        sweep_rows.append({
            "energy_weight": weight,
            "selected_training_seed": best_seed,
            "validation_cost": best_val["composite_cost"],
            **metrics,
        })
        print(f"  lambda={weight:.2f}: seed={best_seed}, rate={metrics['sensing_rate']:.3f}, RMSE={metrics['rmse']:.4f}, F1={metrics['f1']:.3f}")

    pd.DataFrame(sweep_selection_rows).to_csv(results_dir / "energy_sweep_seed_selection.csv", index=False)
    energy_sweep = pd.DataFrame(sweep_rows)
    energy_sweep.to_csv(results_dir / "energy_weight_sweep.csv", index=False)

    print("Evaluating periodic and covariance grids for the Pareto frontier...")
    pareto_rows: List[Dict[str, float | str]] = []
    for _, row in energy_sweep.iterrows():
        pareto_rows.append({
            "method": "RL energy sweep",
            "label": f"λ={row['energy_weight']:.2g}",
            "parameter": row["energy_weight"],
            "sensing_rate": row["sensing_rate"],
            "rmse": row["rmse"],
            "recall": row["recall"],
            "f1": row["f1"],
        })
    for interval in [1, 2, 3, 4, 5, 6, 8, 12, 16, 24]:
        raw = evaluate_policy_raw(selected_q, MAIN_ENERGY_WEIGHT, test_seeds, config.horizon, 0, POLICY_PERIODIC, interval, 0.0)
        metrics = aggregate_metrics(raw)
        pareto_rows.append({
            "method": "Periodic grid", "label": f"k={interval}", "parameter": interval,
            "sensing_rate": metrics["sensing_rate"], "rmse": metrics["rmse"],
            "recall": metrics["recall"], "f1": metrics["f1"],
        })
    for threshold in [0.025, 0.030, 0.040, 0.045, 0.050, 0.060, 0.070, 0.080, 0.100, 0.120, 0.140, 0.180, 0.200, 0.250, 0.300]:
        raw = evaluate_policy_raw(selected_q, MAIN_ENERGY_WEIGHT, test_seeds, config.horizon, 0, POLICY_COVARIANCE, threshold, 0.0)
        metrics = aggregate_metrics(raw)
        pareto_rows.append({
            "method": "Covariance grid", "label": f"P={threshold:g}", "parameter": threshold,
            "sensing_rate": metrics["sensing_rate"], "rmse": metrics["rmse"],
            "recall": metrics["recall"], "f1": metrics["f1"],
        })
    pareto = pd.DataFrame(pareto_rows)
    pareto.to_csv(results_dir / "pareto_points.csv", index=False)

    print("Running model-mismatch robustness experiments...")
    robustness_policy_names = ["Full-rate", "Periodic", "Event trigger", "Proposed RL"]
    robustness_frames: List[pd.DataFrame] = []
    robustness_summary_rows: List[Dict[str, float | str]] = []
    for scenario_id in range(4):
        for index, policy_name in enumerate(robustness_policy_names):
            policy_id, p1, p2 = policies[policy_name]
            raw, summary = evaluate_and_summarize(
                selected_q, MAIN_ENERGY_WEIGHT, test_seeds, config.horizon, scenario_id,
                policy_id, p1, p2, bootstrap_replications, 5000 + scenario_id * 10 + index,
            )
            robustness_frames.append(raw_to_frame(
                raw, test_seeds, policy=policy_name, scenario=SCENARIO_NAMES[scenario_id],
                scenario_id=scenario_id, parameter_1=p1, parameter_2=p2,
            ))
            robustness_summary_rows.append({
                "scenario_id": scenario_id,
                "scenario": SCENARIO_NAMES[scenario_id],
                "policy": policy_name,
                **summary,
            })
    robustness_episode_results = pd.concat(robustness_frames, ignore_index=True)
    robustness_episode_results.to_csv(results_dir / "robustness_episode_results.csv", index=False)
    robustness_summary = pd.DataFrame(robustness_summary_rows)
    robustness_summary.to_csv(results_dir / "robustness_summary.csv", index=False)

    print("Extracting policy-behavior diagnostics and a representative trace...")
    occupancy = occupancy_statistics(selected_q, test_seeds, config.horizon)
    region_labels = ["$\\hat{x}<0.5$", "$0.5\\leq\\hat{x}<0.8$", "$0.8\\leq\\hat{x}<1.1$", "$\\hat{x}\\geq1.1$"]
    behavior = pd.DataFrame({
        "condition_region": region_labels,
        "samples": occupancy[:, 0],
        "decisions": occupancy[:, 1],
        "sensing_probability": np.divide(occupancy[:, 0], occupancy[:, 1], out=np.zeros(4), where=occupancy[:, 1] > 0),
        "decision_share": occupancy[:, 1] / occupancy[:, 1].sum(),
        "mean_age_before_decision": np.divide(occupancy[:, 2], occupancy[:, 1], out=np.zeros(4), where=occupancy[:, 1] > 0),
        "fault_decision_share_within_region": np.divide(occupancy[:, 3], occupancy[:, 1], out=np.zeros(4), where=occupancy[:, 1] > 0),
        "sample_share_during_fault": np.divide(occupancy[:, 4], occupancy[:, 0], out=np.zeros(4), where=occupancy[:, 0] > 0),
    })
    behavior.to_csv(results_dir / "policy_behavior.csv", index=False)

    trace_seed, trace_data = find_representative_seed(selected_q, test_seeds, config.horizon)
    trace_frame = pd.DataFrame({
        "time_min": np.arange(config.horizon),
        "condition": trace_data["condition"],
        "mode": trace_data["mode"],
        "observation": trace_data["observations"],
        "estimate": trace_data["estimate"],
        "variance": trace_data["variance"],
        "age": trace_data["age"],
        "action": trace_data["action"],
        "alarm": trace_data["alarm"],
    })
    trace_frame.to_csv(results_dir / "representative_trace.csv", index=False)

    configure_plotting()
    plot_framework(figures_dir)
    plot_training_curve(training_curves, selected_seed, figures_dir)
    plot_trace(trace_frame, figures_dir, trace_seed)
    plot_main_comparison(main_summary, figures_dir)
    plot_pareto(pareto, figures_dir)
    plot_robustness(robustness_summary, figures_dir)
    plot_policy_behavior(behavior, figures_dir)

    metadata = {
        "study_date": "2026-07-21",
        "python": sys.version,
        "platform": platform.platform(),
        "versions": {
            "numpy": np.__version__,
            "pandas": pd.__version__,
            "matplotlib": matplotlib.__version__,
            "scipy": scipy.__version__,
            "numba": numba.__version__,
        },
        "configuration": {
            "training": config.__dict__,
            "main_energy_weight": MAIN_ENERGY_WEIGHT,
            "main_training_seeds": main_training_seeds.tolist(),
            "sweep_training_seeds": sweep_training_seeds.tolist(),
            "validation_seeds": [int(validation_seeds[0]), int(validation_seeds[-1])],
            "test_seeds": [int(test_seeds[0]), int(test_seeds[-1])],
            "bootstrap_replications": bootstrap_replications,
            "q_states": N_STATES,
            "q_actions": 2,
            "q_table_bytes": q_policy_size_bytes(selected_q),
        },
        "selection": {
            "selected_training_seed": selected_seed,
            "selected_baselines": selected_baselines,
            "representative_trace_seed": trace_seed,
        },
    }
    with (results_dir / "run_metadata.json").open("w", encoding="utf-8") as handle:
        json.dump(metadata, handle, indent=2)

    print("\nCompleted reproducible study.")
    print(f"Results: {results_dir}")
    print(f"Figures: {figures_dir}")


if __name__ == "__main__":
    main()
