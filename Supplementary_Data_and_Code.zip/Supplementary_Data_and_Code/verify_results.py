#!/usr/bin/env python3
"""Verify internal consistency and replay the released main Q-table."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "src"))

from adaptive_sensing_rl import (  # noqa: E402
    POLICY_Q,
    aggregate_metrics,
    evaluate_policy_raw,
    q_policy_size_bytes,
)

ADDITIVE_COLUMNS = [
    "steps",
    "samples",
    "squared_error_sum",
    "absolute_error_sum",
    "true_positive",
    "false_positive",
    "false_negative",
    "cost_sum",
    "fault_steps",
    "delay_sum",
    "fault_events",
]
METRICS = [
    "sensing_rate",
    "energy_saving_vs_full",
    "rmse",
    "mae",
    "recall",
    "precision",
    "f1",
    "composite_cost",
    "fault_prevalence",
    "detection_delay",
    "fault_events",
]


def require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def main() -> None:
    results = ROOT / "results"
    summary = pd.read_csv(results / "main_results_summary.csv")
    episodes = pd.read_csv(results / "main_episode_results.csv")
    metadata = json.loads((results / "run_metadata.json").read_text(encoding="utf-8"))

    require(len(summary) == 6, "Expected six nominal policies")
    require(len(episodes) == 1800, "Expected six policies x 300 episodes")

    maximum_error = 0.0
    for _, released in summary.iterrows():
        policy = str(released["policy"])
        subset = episodes.loc[episodes["policy"] == policy]
        require(len(subset) == 300, f"{policy}: expected 300 episodes")
        require(subset["seed"].nunique() == 300, f"{policy}: duplicate test seeds")
        require(int(subset["seed"].min()) == 20_000, f"{policy}: wrong first seed")
        require(int(subset["seed"].max()) == 20_299, f"{policy}: wrong last seed")

        totals = subset[ADDITIVE_COLUMNS].to_numpy(dtype=float).sum(axis=0, keepdims=True)
        recomputed = aggregate_metrics(totals)
        for metric in METRICS:
            error = abs(float(released[metric]) - float(recomputed[metric]))
            maximum_error = max(maximum_error, error)
            require(error < 1e-12, f"{policy}/{metric}: aggregate mismatch {error}")

    model_path = results / "models" / "selected_policy_lambda_0p20.npz"
    with np.load(model_path) as model:
        q_table = model["q_table"]
        energy_weight = float(model["energy_weight"])
        training_seed = int(model["selected_training_seed"])

    require(q_table.shape == (384, 2), f"Unexpected Q-table shape: {q_table.shape}")
    require(q_policy_size_bytes(q_table) == 6144, "Unexpected Q-table byte count")
    require(abs(energy_weight - 0.20) < 1e-15, "Unexpected main energy weight")
    require(training_seed == 6, "Unexpected selected training seed")

    test_seeds = np.arange(20_000, 20_300, dtype=np.int64)
    replay_raw = evaluate_policy_raw(
        q_table,
        energy_weight,
        test_seeds,
        720,
        0,
        POLICY_Q,
        0.0,
        0.0,
    )
    replay = aggregate_metrics(replay_raw)
    released_rl = summary.loc[summary["policy"] == "Proposed RL"].iloc[0]
    for metric in METRICS:
        error = abs(float(released_rl[metric]) - float(replay[metric]))
        require(error < 1e-12, f"Frozen-policy replay mismatch for {metric}: {error}")

    require(metadata["configuration"]["test_seeds"] == [20_000, 20_299], "Metadata seed mismatch")
    require(metadata["configuration"]["q_table_bytes"] == 6144, "Metadata table-size mismatch")
    require(int(episodes["steps"].sum() / 6) == 216_000, "Unexpected decisions per policy")

    for index in range(1, 8):
        pngs = list((ROOT / "figures").glob(f"figure_{index}_*.png"))
        pdfs = list((ROOT / "figures").glob(f"figure_{index}_*.pdf"))
        require(len(pngs) == 1, f"Figure {index}: expected one PNG, found {len(pngs)}")
        require(len(pdfs) == 1, f"Figure {index}: expected one vector PDF, found {len(pdfs)}")
        require(pngs[0].stat().st_size > 0 and pdfs[0].stat().st_size > 0, f"Figure {index}: empty file")

    print("Release verification passed.")
    print(f"Maximum raw-to-summary absolute error: {maximum_error:.3e}")
    print("Frozen Q-table replay matches the released Proposed RL row exactly.")
    print("Nominal test design: 6 policies x 300 shifts x 720 decisions.")


if __name__ == "__main__":
    main()
