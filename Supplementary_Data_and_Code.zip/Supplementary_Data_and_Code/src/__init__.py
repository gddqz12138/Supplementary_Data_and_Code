"""Reproducible energy-aware adaptive sensing study."""
