"""Energy-aware adaptive sensing simulator and tabular Q-learning agent.

The module is intentionally compact and deterministic.  It implements a
partially observed three-mode industrial condition process, a scalar
Kalman-style belief estimator, a tabular Q-learning sensing policy, and several
non-learning baselines.  All random streams are controlled by integer seeds.

The simulator uses a one-minute decision interval.  The latent condition is
normalized; a value of 1.10 is treated as a fault threshold.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Tuple

import numpy as np
from numba import njit

# ---------------------------------------------------------------------------
# Environment, estimator, and objective constants
# ---------------------------------------------------------------------------
THETA = np.array([0.00, 0.70, 1.85], dtype=np.float64)
PROCESS_STD = np.array([0.04, 0.07, 0.10], dtype=np.float64)
TRANSITION_CDF = np.array(
    [
        [0.992, 0.999, 1.000],  # normal -> normal/load/fault
        [0.040, 0.980, 1.000],  # load   -> normal/load/fault
        [0.000, 0.030, 1.000],  # fault  -> normal/load/fault
    ],
    dtype=np.float64,
)

NOMINAL_RHO = 0.92
NOMINAL_MEASUREMENT_STD = 0.20
FILTER_MEASUREMENT_VARIANCE = NOMINAL_MEASUREMENT_STD**2
FILTER_PROCESS_VARIANCE = 0.012
INITIAL_ESTIMATE = 0.0
INITIAL_VARIANCE = 0.04
FAULT_THRESHOLD = 1.10
ERROR_NORMALIZER = 0.20
FALSE_NEGATIVE_WEIGHT = 1.50
FALSE_POSITIVE_WEIGHT = 0.20

# Belief-state discretization.  len(edges)+1 bins per component.
MU_EDGES = np.array([-0.10, 0.25, 0.50, 0.75, 0.95, 1.10, 1.35], dtype=np.float64)
P_EDGES = np.array([0.020, 0.045, 0.080, 0.140, 0.260], dtype=np.float64)
AGE_EDGES = np.array([0.0, 1.0, 2.0, 3.0, 5.0, 8.0, 13.0], dtype=np.float64)
N_MU_BINS = len(MU_EDGES) + 1
N_P_BINS = len(P_EDGES) + 1
N_AGE_BINS = len(AGE_EDGES) + 1
N_STATES = N_MU_BINS * N_P_BINS * N_AGE_BINS
N_ACTIONS = 2  # 0=skip, 1=sense

# Policy identifiers used inside Numba functions.
POLICY_PERIODIC = 0
POLICY_COVARIANCE = 1
POLICY_EVENT = 2
POLICY_RANDOM = 3
POLICY_Q = 4

# Raw evaluation columns.
RAW_COLUMNS = (
    "steps",
    "samples",
    "squared_error_sum",
    "absolute_error_sum",
    "true_positive",
    "false_positive",
    "false_negative",
    "cost_sum",
    "fault_steps",
    "delay_sum",
    "fault_events",
)

SCENARIO_NAMES: Dict[int, str] = {
    0: "Nominal",
    1: "Measurement noise +50%",
    2: "Fault-entry hazard x5",
    3: "Faster/noisier dynamics",
}


@dataclass(frozen=True)
class TrainingConfig:
    episodes: int = 1800
    horizon: int = 720
    gamma: float = 0.985
    epsilon_start: float = 0.90
    epsilon_end: float = 0.025
    alpha_start: float = 0.22
    alpha_end: float = 0.035


@njit(cache=True)
def _bin_index(value: float, edges: np.ndarray) -> int:
    for i in range(edges.size):
        if value <= edges[i]:
            return i
    return edges.size


@njit(cache=True)
def state_index(mu: float, variance: float, age: float) -> int:
    """Map continuous belief variables to a compact tabular state index."""
    mu_bin = _bin_index(mu, MU_EDGES)
    p_bin = _bin_index(variance, P_EDGES)
    age_bin = _bin_index(age, AGE_EDGES)
    return (mu_bin * N_P_BINS + p_bin) * N_AGE_BINS + age_bin


@njit(cache=True)
def generate_episode(seed: int, horizon: int, scenario: int = 0) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Generate latent condition, operating mode, and measurement-noise arrays."""
    x = np.empty(horizon, dtype=np.float64)
    mode = np.empty(horizon, dtype=np.int8)
    measurement_noise = np.empty(horizon, dtype=np.float64)

    rho = NOMINAL_RHO
    process_multiplier = 1.0
    measurement_std = NOMINAL_MEASUREMENT_STD
    if scenario == 1:
        measurement_std = 0.30  # estimator remains nominal: deliberate mismatch
    elif scenario == 3:
        rho = 0.86
        process_multiplier = 1.30

    np.random.seed(seed)
    u = np.random.random()
    mode[0] = 0 if u < 0.90 else (1 if u < 0.98 else 2)
    x[0] = THETA[mode[0]] + 0.15 * np.random.randn()

    for t in range(1, horizon):
        u = np.random.random()
        previous_mode = mode[t - 1]
        if scenario == 2 and previous_mode == 0:
            # Increase normal-to-fault probability from 0.001 to 0.005.
            next_mode = 0 if u < 0.985 else (1 if u < 0.995 else 2)
        else:
            next_mode = (
                0
                if u < TRANSITION_CDF[previous_mode, 0]
                else (1 if u < TRANSITION_CDF[previous_mode, 1] else 2)
            )
        mode[t] = next_mode
        x[t] = (
            rho * x[t - 1]
            + (1.0 - rho) * THETA[next_mode]
            + process_multiplier * PROCESS_STD[next_mode] * np.random.randn()
        )

    # Use a separate deterministic stream so all policies face identical noise.
    np.random.seed(seed + 1_000_003)
    for t in range(horizon):
        measurement_noise[t] = measurement_std * np.random.randn()
    return x, mode, measurement_noise


@njit(cache=True)
def train_q_learning_numba(
    energy_weight: float,
    training_seed: int,
    episodes: int,
    horizon: int,
    gamma: float,
    epsilon_start: float,
    epsilon_end: float,
    alpha_start: float,
    alpha_end: float,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Train a two-action tabular Q-learning policy in the nominal simulator."""
    q_table = np.zeros((N_STATES, N_ACTIONS), dtype=np.float64)
    episode_cost = np.empty(episodes, dtype=np.float64)
    episode_sampling_rate = np.empty(episodes, dtype=np.float64)

    for episode in range(episodes):
        environment_seed = training_seed * 10_000_000 + episode + 1
        x, _, measurement_noise = generate_episode(environment_seed, horizon, 0)
        np.random.seed(training_seed * 20_000_000 + episode + 123)

        mu = INITIAL_ESTIMATE
        variance = INITIAL_VARIANCE
        age = 0.0
        fraction = episode / max(1, episodes - 1)
        epsilon = max(epsilon_end, epsilon_start * (epsilon_end / epsilon_start) ** fraction)
        alpha = max(alpha_end, alpha_start * (alpha_end / alpha_start) ** fraction)
        s = state_index(mu, variance, age)
        total_cost = 0.0
        total_samples = 0.0

        for t in range(horizon):
            if np.random.random() < epsilon:
                action = 0 if np.random.random() < 0.5 else 1
            else:
                q_skip = q_table[s, 0]
                q_sense = q_table[s, 1]
                if abs(q_skip - q_sense) < 1e-12:
                    action = 0 if np.random.random() < 0.5 else 1
                else:
                    action = 1 if q_sense > q_skip else 0

            if action == 1:
                observation = x[t] + measurement_noise[t]
                innovation_variance = variance + FILTER_MEASUREMENT_VARIANCE
                gain = variance / innovation_variance
                mu = mu + gain * (observation - mu)
                variance = variance * (1.0 - gain)
                age = 0.0
                total_samples += 1.0
            else:
                age = min(age + 1.0, 60.0)

            error = x[t] - mu
            fault = x[t] >= FAULT_THRESHOLD
            alarm = mu >= FAULT_THRESHOLD
            step_cost = (
                error * error / ERROR_NORMALIZER
                + energy_weight * action
                + FALSE_NEGATIVE_WEIGHT * (fault and not alarm)
                + FALSE_POSITIVE_WEIGHT * ((not fault) and alarm)
            )
            total_cost += step_cost
            reward = -step_cost

            # Random-walk belief prediction for the next decision.
            variance = min(variance + FILTER_PROCESS_VARIANCE, 1.0)
            terminal = t == horizon - 1
            if terminal:
                target = reward
            else:
                next_state = state_index(mu, variance, age)
                target = reward + gamma * max(q_table[next_state, 0], q_table[next_state, 1])
            q_table[s, action] += alpha * (target - q_table[s, action])
            if not terminal:
                s = next_state

        episode_cost[episode] = total_cost / horizon
        episode_sampling_rate[episode] = total_samples / horizon

    return q_table, episode_cost, episode_sampling_rate


def train_q_learning(
    energy_weight: float,
    training_seed: int,
    config: TrainingConfig = TrainingConfig(),
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Python wrapper around the compiled training routine."""
    return train_q_learning_numba(
        float(energy_weight),
        int(training_seed),
        int(config.episodes),
        int(config.horizon),
        float(config.gamma),
        float(config.epsilon_start),
        float(config.epsilon_end),
        float(config.alpha_start),
        float(config.alpha_end),
    )


@njit(cache=True)
def evaluate_policy_raw(
    q_table: np.ndarray,
    energy_weight: float,
    seeds: np.ndarray,
    horizon: int,
    scenario: int = 0,
    policy: int = POLICY_Q,
    parameter_1: float = 0.0,
    parameter_2: float = 0.0,
) -> np.ndarray:
    """Return additive episode-level outcomes for a policy.

    The 11 output columns follow RAW_COLUMNS.  Additive storage permits exact
    micro-aggregation and nonparametric bootstrap resampling by episode.
    """
    output = np.empty((seeds.size, len(RAW_COLUMNS)), dtype=np.float64)

    for episode_index in range(seeds.size):
        seed = int(seeds[episode_index])
        x, _, measurement_noise = generate_episode(seed, horizon, scenario)
        np.random.seed(seed + 7_000_003 + policy)

        mu = INITIAL_ESTIMATE
        variance = INITIAL_VARIANCE
        age = 0.0
        normalized_innovation = 0.0

        samples = 0.0
        squared_error_sum = 0.0
        absolute_error_sum = 0.0
        true_positive = 0.0
        false_positive = 0.0
        false_negative = 0.0
        cost_sum = 0.0
        fault_steps = 0.0
        delay_sum = 0.0
        fault_events = 0.0
        in_fault_event = False
        event_detected = False
        event_delay = 0.0

        for t in range(horizon):
            if policy == POLICY_Q:
                s = state_index(mu, variance, age)
                action = 1 if q_table[s, 1] > q_table[s, 0] else 0
            elif policy == POLICY_PERIODIC:
                interval = max(1, int(parameter_1))
                action = 1 if t % interval == 0 else 0
            elif policy == POLICY_COVARIANCE:
                action = 1 if variance >= parameter_1 else 0
            elif policy == POLICY_EVENT:
                action = 1 if (
                    variance >= parameter_1
                    or abs(normalized_innovation) >= parameter_2
                    or (mu >= 0.8 * FAULT_THRESHOLD and age >= 2.0)
                ) else 0
            else:  # POLICY_RANDOM
                action = 1 if np.random.random() < parameter_1 else 0

            if action == 1:
                observation = x[t] + measurement_noise[t]
                innovation_variance = variance + FILTER_MEASUREMENT_VARIANCE
                innovation = observation - mu
                gain = variance / innovation_variance
                mu = mu + gain * innovation
                variance = variance * (1.0 - gain)
                age = 0.0
                normalized_innovation = innovation / np.sqrt(innovation_variance)
                normalized_innovation = max(-5.0, min(5.0, normalized_innovation))
                samples += 1.0
            else:
                age = min(age + 1.0, 60.0)
                normalized_innovation *= 0.75

            error = x[t] - mu
            fault = x[t] >= FAULT_THRESHOLD
            alarm = mu >= FAULT_THRESHOLD
            squared_error_sum += error * error
            absolute_error_sum += abs(error)
            fault_steps += fault

            if fault and alarm:
                true_positive += 1.0
            elif (not fault) and alarm:
                false_positive += 1.0
            elif fault and (not alarm):
                false_negative += 1.0

            cost_sum += (
                error * error / ERROR_NORMALIZER
                + energy_weight * action
                + FALSE_NEGATIVE_WEIGHT * (fault and not alarm)
                + FALSE_POSITIVE_WEIGHT * ((not fault) and alarm)
            )

            # Detection delay for contiguous threshold-exceedance episodes.
            if fault and not in_fault_event:
                in_fault_event = True
                event_detected = False
                event_delay = 0.0
                fault_events += 1.0
            if in_fault_event:
                if (not event_detected) and alarm:
                    event_detected = True
                    delay_sum += event_delay
                if not event_detected:
                    event_delay += 1.0
                if (not fault) or t == horizon - 1:
                    if not event_detected:
                        delay_sum += event_delay
                    in_fault_event = False

            variance = min(variance + FILTER_PROCESS_VARIANCE, 1.0)

        output[episode_index, 0] = horizon
        output[episode_index, 1] = samples
        output[episode_index, 2] = squared_error_sum
        output[episode_index, 3] = absolute_error_sum
        output[episode_index, 4] = true_positive
        output[episode_index, 5] = false_positive
        output[episode_index, 6] = false_negative
        output[episode_index, 7] = cost_sum
        output[episode_index, 8] = fault_steps
        output[episode_index, 9] = delay_sum
        output[episode_index, 10] = fault_events

    return output


@njit(cache=True)
def occupancy_statistics(q_table: np.ndarray, seeds: np.ndarray, horizon: int) -> np.ndarray:
    """Empirical policy behavior across four estimated-condition regions.

    Columns: samples, decisions, accumulated age, fault decisions, samples in fault.
    """
    output = np.zeros((4, 5), dtype=np.float64)
    for episode_index in range(seeds.size):
        x, _, measurement_noise = generate_episode(int(seeds[episode_index]), horizon, 0)
        mu = INITIAL_ESTIMATE
        variance = INITIAL_VARIANCE
        age = 0.0
        for t in range(horizon):
            if mu < 0.50:
                region = 0
            elif mu < 0.80:
                region = 1
            elif mu < FAULT_THRESHOLD:
                region = 2
            else:
                region = 3

            s = state_index(mu, variance, age)
            action = 1 if q_table[s, 1] > q_table[s, 0] else 0
            fault = x[t] >= FAULT_THRESHOLD
            output[region, 0] += action
            output[region, 1] += 1.0
            output[region, 2] += age
            output[region, 3] += fault
            output[region, 4] += action * fault

            if action == 1:
                observation = x[t] + measurement_noise[t]
                innovation_variance = variance + FILTER_MEASUREMENT_VARIANCE
                gain = variance / innovation_variance
                mu = mu + gain * (observation - mu)
                variance = variance * (1.0 - gain)
                age = 0.0
            else:
                age = min(age + 1.0, 60.0)
            variance = min(variance + FILTER_PROCESS_VARIANCE, 1.0)
    return output


def simulate_trace(
    q_table: np.ndarray,
    seed: int,
    horizon: int = 720,
    scenario: int = 0,
) -> Dict[str, np.ndarray]:
    """Simulate one greedy Q-policy trajectory for plotting and inspection."""
    x, mode, measurement_noise = generate_episode(int(seed), int(horizon), int(scenario))
    mu = INITIAL_ESTIMATE
    variance = INITIAL_VARIANCE
    age = 0.0

    observations = np.full(horizon, np.nan, dtype=float)
    estimates = np.empty(horizon, dtype=float)
    variances = np.empty(horizon, dtype=float)
    ages = np.empty(horizon, dtype=float)
    actions = np.empty(horizon, dtype=np.int8)
    alarms = np.empty(horizon, dtype=np.int8)

    for t in range(horizon):
        s = state_index(mu, variance, age)
        action = 1 if q_table[s, 1] > q_table[s, 0] else 0
        actions[t] = action
        ages[t] = age
        if action:
            observation = x[t] + measurement_noise[t]
            observations[t] = observation
            innovation_variance = variance + FILTER_MEASUREMENT_VARIANCE
            gain = variance / innovation_variance
            mu = mu + gain * (observation - mu)
            variance = variance * (1.0 - gain)
            age = 0.0
        else:
            age = min(age + 1.0, 60.0)
        estimates[t] = mu
        alarms[t] = int(mu >= FAULT_THRESHOLD)
        variance = min(variance + FILTER_PROCESS_VARIANCE, 1.0)
        variances[t] = variance

    return {
        "condition": np.asarray(x),
        "mode": np.asarray(mode),
        "observations": observations,
        "estimate": estimates,
        "variance": variances,
        "age": ages,
        "action": actions,
        "alarm": alarms,
    }


def aggregate_metrics(raw: np.ndarray) -> Dict[str, float]:
    """Compute micro-averaged metrics from additive episode-level outcomes."""
    totals = np.asarray(raw, dtype=float).sum(axis=0)
    steps = totals[0]
    samples = totals[1]
    squared_error = totals[2]
    absolute_error = totals[3]
    tp, fp, fn = totals[4], totals[5], totals[6]
    cost_sum = totals[7]
    fault_steps = totals[8]
    delay_sum = totals[9]
    fault_events = totals[10]

    recall = tp / (tp + fn) if tp + fn > 0 else 1.0
    precision = tp / (tp + fp) if tp + fp > 0 else 1.0
    f1 = 2.0 * recall * precision / (recall + precision) if recall + precision > 0 else 0.0
    sensing_rate = samples / steps
    return {
        "sensing_rate": sensing_rate,
        "energy_saving_vs_full": 1.0 - sensing_rate,
        "rmse": float(np.sqrt(squared_error / steps)),
        "mae": absolute_error / steps,
        "recall": recall,
        "precision": precision,
        "f1": f1,
        "composite_cost": cost_sum / steps,
        "fault_prevalence": fault_steps / steps,
        "detection_delay": delay_sum / fault_events if fault_events > 0 else 0.0,
        "fault_events": fault_events,
    }


def q_policy_size_bytes(q_table: np.ndarray) -> int:
    return int(np.asarray(q_table).nbytes)
